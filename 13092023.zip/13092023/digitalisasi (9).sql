-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 13, 2023 at 06:57 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitalisasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `leader`
--

CREATE TABLE `leader` (
  `No` int(11) NOT NULL,
  `Uid` varchar(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Line` varchar(255) NOT NULL,
  `Station` varchar(255) NOT NULL,
  `Area` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `DepartTo` varchar(255) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `Dateout` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leader`
--

INSERT INTO `leader` (`No`, `Uid`, `Nama`, `Line`, `Station`, `Area`, `Status`, `DepartTo`, `Date`, `Dateout`) VALUES
(56, 'INC192', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'SPI (TOP)', 'SMT TOP', 'Solved', 'PURCHASING,PPIC,MP&L', '2023-09-11 08:29:12', '2023-09-11 08:29:49'),
(57, 'INC342', 'Nadira. S (0816)', 'SMT LINE 1', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'MAINTENANCE & IT', '2023-09-12 03:29:02', '2023-09-12 03:30:25'),
(58, 'INC820', 'Nadira. S (0816)', 'SMT LINE 1', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'PURCHASING,PPIC,MP&L', '2023-09-12 03:45:04', '2023-09-12 03:45:29'),
(59, 'INC519', 'Aldi Apriliansyah (0734)', 'SMT LINE 1', 'SPI (TOP)', 'SMT TOP', 'Solved', 'HRGA & EHS', '2023-09-12 03:59:20', '2023-09-12 04:00:35'),
(60, 'INC841', 'Aldi Apriliansyah (0734)', 'SMT LINE 1', 'Reflow (BOT)', 'SMT BOT', 'Solved', 'MAINTENANCE & IT', '2023-09-12 08:50:56', '2023-09-12 08:51:35');

-- --------------------------------------------------------

--
-- Table structure for table `repair`
--

CREATE TABLE `repair` (
  `No` int(11) NOT NULL,
  `Uid` varchar(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Line` varchar(255) NOT NULL,
  `Problem` varchar(255) NOT NULL,
  `Station` varchar(255) NOT NULL,
  `Area` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `ResponseName` varchar(255) NOT NULL,
  `ResponseTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `ResponseDone` timestamp NOT NULL DEFAULT current_timestamp(),
  `Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `DepartTo` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Requestor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repair`
--

INSERT INTO `repair` (`No`, `Uid`, `Nama`, `Line`, `Problem`, `Station`, `Area`, `Status`, `ResponseName`, `ResponseTime`, `ResponseDone`, `Date`, `DepartTo`, `Department`, `Requestor`) VALUES
(262, 'INC192', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Kurang stok', 'SPI (TOP)', 'SMT TOP', 'Solved', 'Eufrat (0776)', '2023-09-11 08:30:24', '2023-09-11 08:33:44', '2023-09-11 08:29:49', 'Sub Leader', 'PURCHASING,PPIC,MP&L', 'Leader'),
(264, 'INC572', 'Aldi Apriliansyah (0734)', 'SMT LINE 1', 'Ok', 'Destacker (TOP)', 'SMT TOP', 'Solved', 'Sugeng S (0011)', '2023-09-11 09:20:04', '2023-09-11 09:20:14', '2023-09-11 09:19:19', 'QC', 'MAINTENANCE & IT', 'Operator'),
(265, 'INC342', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Mesin rusak', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'Sugeng S (0011)', '2023-09-12 03:38:55', '2023-09-12 03:40:03', '2023-09-12 03:30:25', 'Sub Leader', 'MAINTENANCE & IT', 'Leader'),
(266, 'INC535', 'Aldi Apriliansyah (0734)', 'SMT LINE 1', 'Rusak nih', 'Destacker (TOP)', 'SMT TOP', 'Solved', 'Sugeng S (0011)', '2023-09-12 03:39:41', '2023-09-12 03:41:23', '2023-09-12 03:38:25', 'QC', 'MAINTENANCE & IT', 'Operator'),
(267, 'INC820', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Help', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'Eufrat (0776)', '2023-09-12 03:45:58', '2023-09-12 03:46:15', '2023-09-12 03:45:29', 'QC', 'PURCHASING,PPIC,MP&L', 'Leader'),
(268, 'INC519', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Kejepit', 'SPI (TOP)', 'SMT TOP', 'Solved', 'Nadira. S (0816)', '2023-09-12 04:01:14', '2023-09-12 04:01:35', '2023-09-12 04:00:35', 'Sub Leader', 'HRGA & EHS', 'Leader'),
(269, 'INC841', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Rusak Mesinya', 'Reflow (BOT)', 'SMT BOT', 'Repair', 'Sugeng S (0011)', '2023-09-12 08:52:36', '2023-09-12 08:53:50', '2023-09-12 08:51:35', 'Production Leader', 'MAINTENANCE & IT', 'Leader');

-- --------------------------------------------------------

--
-- Table structure for table `returnrepair`
--

CREATE TABLE `returnrepair` (
  `No` int(11) NOT NULL,
  `Uid` varchar(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Line` varchar(255) NOT NULL,
  `Problem` varchar(255) NOT NULL,
  `Station` varchar(255) NOT NULL,
  `Area` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `ResponseName` varchar(255) NOT NULL,
  `ResponseTime` timestamp NOT NULL DEFAULT current_timestamp(),
  `ResponseDone` timestamp NOT NULL DEFAULT current_timestamp(),
  `Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `DepartTo` varchar(255) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Requestor` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returnrepair`
--

INSERT INTO `returnrepair` (`No`, `Uid`, `Nama`, `Line`, `Problem`, `Station`, `Area`, `Status`, `ResponseName`, `ResponseTime`, `ResponseDone`, `Date`, `DepartTo`, `Department`, `Requestor`) VALUES
(26, 'INC192', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Oke', 'SPI (TOP)', 'SMT TOP', 'Solved', 'Nadira. S (0816)', '2023-09-11 08:48:01', '2023-09-11 08:48:15', '2023-09-11 08:46:24', 'Production Leader', 'ADVANCED MANUFACTURING ENGINEERING', 'Leader'),
(27, 'INC342', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Masih rusak', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'Sugeng S (0011)', '2023-09-12 03:33:26', '2023-09-12 03:33:55', '2023-09-12 03:32:54', 'Sub Leader', 'MAINTENANCE & IT', 'Leader'),
(28, 'INC820', 'Fajar Eko S (0064)', 'SMT LINE 1', 'Tolong di cek', 'Reflow (TOP)', 'SMT TOP', 'Solved', 'Sugeng S (0011)', '2023-09-12 03:48:01', '2023-09-12 03:48:10', '2023-09-12 03:47:27', 'QC', 'MAINTENANCE & IT', 'Quality'),
(29, 'INC841', 'Dwi Anggraeni (0141)', 'SMT LINE 1', 'Belum betul', 'Reflow (BOT)', 'SMT BOT', 'Solved', 'Eufrat (0776)', '2023-09-12 08:55:44', '2023-09-12 08:55:55', '2023-09-12 08:55:00', 'Production Leader', 'PURCHASING,PPIC,MP&L', 'Leader');

-- --------------------------------------------------------

--
-- Table structure for table `returnvalidation`
--

CREATE TABLE `returnvalidation` (
  `No` int(11) NOT NULL,
  `Uid` varchar(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Line` varchar(255) NOT NULL,
  `Problem` varchar(255) NOT NULL,
  `Action` varchar(255) NOT NULL,
  `Station` varchar(255) NOT NULL,
  `Area` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `DepartTo` varchar(255) NOT NULL,
  `Requestor` varchar(255) NOT NULL,
  `ValidationName` varchar(255) NOT NULL,
  `ValidationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `ValidationDescription` varchar(255) NOT NULL,
  `ReturnDepartment` varchar(255) NOT NULL,
  `DownTime` varchar(255) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `returnvalidation`
--

INSERT INTO `returnvalidation` (`No`, `Uid`, `Nama`, `Line`, `Problem`, `Action`, `Station`, `Area`, `Status`, `DepartTo`, `Requestor`, `ValidationName`, `ValidationDate`, `ValidationDescription`, `ReturnDepartment`, `DownTime`, `Date`) VALUES
(3, 'INC192', 'Nadira. S (0816)', 'SMT LINE 1', 'Ok', 'Ok', 'SPI (TOP)', 'SMT TOP', 'Running', 'Production Leader', 'ADVANCED MANUFACTURING ENGINEERING [Return]', 'Dwi Anggraeni (0141)', '2023-09-11 08:50:08', 'Aman', '', '0 Hours : 0 Minutes : 2 Seconds ', '2023-09-11 08:48:15'),
(4, 'INC342', 'Sugeng S (0011)', 'SMT LINE 1', 'Sudah benar ', 'Sudah aman', 'Reflow (TOP)', 'SMT TOP', 'Running', 'Sub Leader', 'MAINTENANCE & IT [Return]', 'Dwi Anggraeni (0141)', '2023-09-12 03:35:07', 'Oke', '', '0 Hours : 6 Minutes : 5 Seconds ', '2023-09-12 03:33:56'),
(5, 'INC820', 'Sugeng S (0011)', 'SMT LINE 1', 'Oke', 'Oke', 'Reflow (TOP)', 'SMT TOP', 'Running', 'QC', 'MAINTENANCE & IT [Return]', 'Fajar Eko S (0064)', '2023-09-12 03:48:51', 'Oke', '', '0 Hours : 0 Minutes : 13 Seconds ', '2023-09-12 03:48:11'),
(6, 'INC841', 'Eufrat (0776)', 'SMT LINE 1', 'Sudah', 'Sudah', 'Reflow (BOT)', 'SMT BOT', 'Running', 'Production Leader', 'PURCHASING,PPIC,MP&L [Return]', 'Dwi Anggraeni (0141)', '2023-09-12 08:56:43', 'Oke', '', '0 Hours : 0 Minutes : 7 Seconds ', '2023-09-12 08:55:56');

-- --------------------------------------------------------

--
-- Table structure for table `scheprod`
--

CREATE TABLE `scheprod` (
  `No` int(20) NOT NULL,
  `SHIFT` varchar(255) DEFAULT NULL,
  `PT1_IN` varchar(5) DEFAULT NULL,
  `PT1_OUT` varchar(5) DEFAULT NULL,
  `PT2_IN` varchar(5) DEFAULT NULL,
  `PT2_OUT` varchar(5) DEFAULT NULL,
  `PT3_IN` varchar(5) DEFAULT NULL,
  `PT3_OUT` varchar(5) DEFAULT NULL,
  `PT4_IN` varchar(5) DEFAULT NULL,
  `PT4_OUT` varchar(5) DEFAULT NULL,
  `BR1_IN` varchar(5) DEFAULT NULL,
  `BR1_OUT` varchar(5) DEFAULT NULL,
  `BR2_IN` varchar(5) DEFAULT NULL,
  `BR2_OUT` varchar(5) DEFAULT NULL,
  `BR3_IN` varchar(5) DEFAULT NULL,
  `BR3_OUT` varchar(5) DEFAULT NULL,
  `BR4_IN` varchar(5) DEFAULT NULL,
  `BR4_OUT` varchar(5) DEFAULT NULL,
  `PD_IN` varchar(5) DEFAULT NULL,
  `PD_OUT` varchar(5) DEFAULT NULL,
  `OT_IN` varchar(5) DEFAULT NULL,
  `OT_OUT` varchar(5) DEFAULT NULL,
  `PP` varchar(255) NOT NULL,
  `PD` varchar(255) NOT NULL,
  `CMA` varchar(255) NOT NULL,
  `ResultsCMA` varchar(255) NOT NULL,
  `RealPT1` varchar(255) NOT NULL,
  `RealPT2` varchar(255) NOT NULL,
  `RealPT3` varchar(255) NOT NULL,
  `RealPT4` varchar(255) NOT NULL,
  `RealPD` varchar(255) NOT NULL,
  `RealOT` varchar(255) NOT NULL,
  `Total` varchar(255) NOT NULL,
  `PDATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scheprod`
--

INSERT INTO `scheprod` (`No`, `SHIFT`, `PT1_IN`, `PT1_OUT`, `PT2_IN`, `PT2_OUT`, `PT3_IN`, `PT3_OUT`, `PT4_IN`, `PT4_OUT`, `BR1_IN`, `BR1_OUT`, `BR2_IN`, `BR2_OUT`, `BR3_IN`, `BR3_OUT`, `BR4_IN`, `BR4_OUT`, `PD_IN`, `PD_OUT`, `OT_IN`, `OT_OUT`, `PP`, `PD`, `CMA`, `ResultsCMA`, `RealPT1`, `RealPT2`, `RealPT3`, `RealPT4`, `RealPD`, `RealOT`, `Total`, `PDATE`) VALUES
(182, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(183, '2', '10:30', '10:31', '10:34', '10:35', '10:38', '10:39', '10:42', '10:43', '10:32', '10:33', '10:36', '10:37', '10:40', '10:41', '10:44', '10:45', '10:48', '10:49', '10:46', '10:47', '8 Hours : 0 Minutes', '', '', '7 menit', '1 menit', '1 menit', '1 menit', '1 menit', '1 menit', '1 menit', '0 jam 6 menit', '2023-06-22 17:00:00'),
(184, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(185, '2', '09:14', '09:15', '09:16', '09:17', '09:18', '09:19', '09:20', '09:21', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '17:00', '17:01', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '1 menit', '1 menit', '1 menit', '1 menit', 'Waiting...', 'Waiting...', '0 jam 4 menit', '2023-07-04 17:00:00'),
(186, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(187, '2', '09:27', '09:28', '09:29', '09:30', '09:31', '09:32', '09:33', '09:34', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '0 jam 1 menit', '', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 1 menit', '2023-07-04 17:00:00'),
(188, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(189, '2', '09:31', '09:32', '09:33', '09:34', '09:35', '09:36', '09:37', '09:38', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '1 menit', '1 menit', '1 menit', '1 menit', 'Waiting...', 'Waiting...', '0 jam 4 menit', '2023-07-04 17:00:00'),
(190, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(218, '2', '08:41', '08:42', '08:43', '08:44', '08:45', '08:46', '08:47', '08:48', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', 'Running', 'Running', 'Running', 'Running', 'Waiting...', 'Waiting...', '0 jam 0 menit', '2023-07-17 17:00:00'),
(219, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(220, '2', '09:36', '09:37', '09:38', '09:39', '09:40', '09:41', '09:42', '09:43', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', 'Running', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 0 menit', '2023-07-17 17:00:00'),
(221, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(222, '2', '09:39', '09:41', '09:42', '09:45', '09:46', '09:48', '09:49', '09:51', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '2 menit', '3 menit', '2 menit', '2 menit', 'Waiting...', 'Waiting...', '0 jam 9 menit', '2023-07-17 17:00:00'),
(223, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(224, '2', '07:00', '09:45', '10:00', '12:00', '14:00', '15:45', '16:00', '16:30', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '1 jam 48 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '1 jam 48 menit', '2023-07-20 17:00:00'),
(225, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '1 jam 48 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '1 jam 48 menit', '0000-00-00 00:00:00'),
(226, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(227, '2', '10:58', '10:59', '10:00', '12:00', '14:00', '15:45', '16:00', '16:30', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '1 menit', '1 jam', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 2 menit', '2023-07-20 17:00:00'),
(228, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Waiting...', '1 jam', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 1 menit', '0000-00-00 00:00:00'),
(229, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(230, '2', '07:00', '09:45', '10:00', '12:00', '14:00', '15:45', '16:00', '16:30', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', 'Waiting...', '1 jam 2 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '1 jam 2 menit', '2023-07-20 17:00:00'),
(231, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Waiting...', '1 jam 2 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '1 jam 2 menit', '0000-00-00 00:00:00'),
(232, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(233, '2', '07:00', '09:45', '10:00', '12:00', '14:00', '15:45', '16:00', '16:30', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '8 jam', '1 jam 9 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '1 jam 17 menit', '2023-07-20 17:00:00'),
(234, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(235, '2', '11:14', '11:15', '11:16', '12:16', '14:00', '15:45', '16:00', '16:30', '09:45', '10:00', '12:00', '13:00', '15:45', '16:00', '16:30', '16:40', 'Null', 'Null', 'Null', 'Null', '8 Hours : 0 Minutes', '', '', '', '1 menit', '13 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 14 menit', '2023-07-20 17:00:00'),
(236, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00 00:00:00'),
(237, '1', '21:00', '00:00', '00:40', '03:00', '03:15', '04:40', '05:00', '06:15', '00:00', '00:40', '03:00', '03:15', '04:00', '05:00', 'Null', 'Null', 'Null', 'Null', '01:26', '03:26', '8 Hours : 0 Minutes', '', '', '', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 0 menit', '2023-07-26 17:00:00'),
(238, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Waiting...', '5 jam 36 menit', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '5 jam 36 menit', '0000-00-00 00:00:00'),
(239, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 0 menit', '0000-00-00 00:00:00'),
(240, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', 'Waiting...', '0 jam 0 menit', '0000-00-00 00:00:00'),
(241, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0 Jam 4 Menit 58 Detik', '', '', '', '', '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `validation`
--

CREATE TABLE `validation` (
  `No` int(11) NOT NULL,
  `Uid` varchar(255) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Line` varchar(255) NOT NULL,
  `Problem` varchar(255) NOT NULL,
  `Action` varchar(255) NOT NULL,
  `Station` varchar(255) NOT NULL,
  `Area` varchar(255) NOT NULL,
  `Status` varchar(255) NOT NULL,
  `DepartTo` varchar(255) NOT NULL,
  `Requestor` varchar(255) NOT NULL,
  `ValidationName` varchar(255) NOT NULL,
  `ValidationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `ValidationDescription` varchar(255) NOT NULL,
  `ReturnDepartment` varchar(255) NOT NULL,
  `DownTime` varchar(255) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `validation`
--

INSERT INTO `validation` (`No`, `Uid`, `Nama`, `Line`, `Problem`, `Action`, `Station`, `Area`, `Status`, `DepartTo`, `Requestor`, `ValidationName`, `ValidationDate`, `ValidationDescription`, `ReturnDepartment`, `DownTime`, `Date`) VALUES
(143, 'INC192', 'Eufrat (0776)', 'SMT LINE 1', 'Teruskan ke advance', 'Teruskan ke advance', 'SPI (TOP)', 'SMT TOP', 'Return', 'Sub Leader', 'PURCHASING,PPIC,MP&L', '', '2023-09-11 08:46:24', '', 'ADVANCED MANUFACTURING ENGINEERING', '0 Hours : 25 Minutes : 34 Seconds ', '2023-09-11 08:33:45'),
(145, 'INC572', 'Sugeng S (0011)', 'SMT LINE 1', 'Oke', 'Oke', 'Destacker (TOP)', 'SMT TOP', 'Running', 'QC', 'MAINTENANCE & IT', 'Fajar Eko S (0064)', '2023-09-11 09:25:26', 'Oke', '', '', '2023-09-11 09:20:14'),
(146, 'INC342', 'Sugeng S (0011)', 'SMT LINE 1', 'Rusak biasa', 'Sudah bisa jalan', 'Reflow (TOP)', 'SMT TOP', 'Return', 'Production Leader', 'MAINTENANCE & IT', '', '2023-09-12 03:32:53', '', 'MAINTENANCE & IT', '', '2023-09-12 03:31:58'),
(148, 'INC535', 'Sugeng S (0011)', 'SMT LINE 1', 'Oke', 'Oke', 'Destacker (TOP)', 'SMT TOP', 'Running', 'QC', 'MAINTENANCE & IT', 'Fajar Eko S (0064)', '2023-09-12 03:43:11', 'Oke', '', '0 Hours : 4 Minutes : 46 Seconds ', '2023-09-12 03:41:24'),
(149, 'INC820', 'Eufrat (0776)', 'SMT LINE 1', 'Sudah', 'Sudah', 'Reflow (TOP)', 'SMT TOP', 'Return', 'QC', 'PURCHASING,PPIC,MP&L', '', '2023-09-12 03:47:27', '', 'MAINTENANCE & IT', '', '2023-09-12 03:46:16'),
(150, 'INC519', 'Nadira. S (0816)', 'SMT LINE 1', 'Oke', 'Oke', 'SPI (TOP)', 'SMT TOP', 'Running', 'Sub Leader', 'HRGA & EHS', 'Dwi Anggraeni (0141)', '2023-09-12 04:02:19', 'Okee', '', '0 Hours : 2 Minutes : 57 Seconds ', '2023-09-12 04:01:35'),
(151, 'INC841', 'Sugeng S (0011)', 'SMT LINE 1', 'Oke ', 'Aman', 'Reflow (BOT)', 'SMT BOT', 'Return', 'Production Leader', 'MAINTENANCE & IT', '', '2023-09-12 08:54:59', '', 'PURCHASING,PPIC,MP&L', '', '2023-09-12 08:53:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leader`
--
ALTER TABLE `leader`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `repair`
--
ALTER TABLE `repair`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `returnrepair`
--
ALTER TABLE `returnrepair`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `returnvalidation`
--
ALTER TABLE `returnvalidation`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `scheprod`
--
ALTER TABLE `scheprod`
  ADD PRIMARY KEY (`No`);

--
-- Indexes for table `validation`
--
ALTER TABLE `validation`
  ADD PRIMARY KEY (`No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leader`
--
ALTER TABLE `leader`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `repair`
--
ALTER TABLE `repair`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=270;

--
-- AUTO_INCREMENT for table `returnrepair`
--
ALTER TABLE `returnrepair`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `returnvalidation`
--
ALTER TABLE `returnvalidation`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `scheprod`
--
ALTER TABLE `scheprod`
  MODIFY `No` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=242;

--
-- AUTO_INCREMENT for table `validation`
--
ALTER TABLE `validation`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
